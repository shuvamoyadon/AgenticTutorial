print('Hello, Lightning World!')
print('anything you can code on your laptop, you can code here')
